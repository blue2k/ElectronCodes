# electron-pref

[![Build Status](https://travis-ci.org/lemonce/electron-pref.svg?branch=master)](https://travis-ci.org/lemonce/electron-pref)

> 简单可依赖的 electron 配置文件管理

自动将您的 electron 应用的配置文件保存在 electron.app.getPath('UserData') 文件夹下。  

你即可在 main 进程也可以在 renderer 进程中使用，且可以与webpack搭配使用。

## 安装
> npm install --save electron-pref

## 使用方法
```JavaScript
const pref = require('electron-pref');
const setting = pref.from({
	name: '全蛋'
});

console.log(setting.get('name'));
// -> '全蛋'

setting.set('name', '铁柱');
console.log(setting.get('name'));
// -> '铁柱'
```

## license
[MIT](LICENSE)
