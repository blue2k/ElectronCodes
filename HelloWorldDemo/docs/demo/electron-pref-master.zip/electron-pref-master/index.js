'use strict';
const electron = require('electron');
const Pref = require('./lib');

const appDataPath = (electron.app || electron.remote.app).getPath('userData');

function newPref(defaultSetting) {
	return new Pref({
		path: appDataPath,
		default: defaultSetting
	});
}

Pref.from = newPref;
Pref.new = newPref;

Pref.withName = function (name, setting) {
	return new Pref({
		name,
		path: appDataPath,
		default: setting
	});
};

module.exports = Pref;
