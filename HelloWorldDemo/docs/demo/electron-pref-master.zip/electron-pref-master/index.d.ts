// http://stackoverflow.com/questions/30019542/es6-map-in-typescript
interface Map<K, V> {
    clear(): void;
    delete(key: K): boolean;
    forEach(callbackfn: (value: V, index: K, map: Map<K, V>) => void, thisArg?: any): void;
    get(key: K): V;
    has(key: K): boolean;
    set(key: K, value?: V): Map<K, V>;
    size: number;
}

export type MapKey = string | number;

export interface Pref {
	get(key: MapKey): string,
	set(key: MapKey, val?: string): void,
	has(key: MapKey): boolean,
	delete(key: MapKey): void,
	del(key: MapKey): void,
	clear(): void,
	path: string,
	size: number,
	store: Map<MapKey, string>
}

export namespace pref {
	/**
	 * get a new configuration object from disk
	 * and if it is not found on disk then is build from
	 * the default paramter.
	 */
	export function from(setting: Object): Pref;
	/**
	 * get a new config object with a specific name.
	 * otherwise it works the same as `from` method
	 */
	export function withName(name: string, setting: Object): Pref;
}
