# electron-pref

[![Build Status](https://travis-ci.org/lemonce/electron-pref.svg?branch=master)](https://travis-ci.org/lemonce/electron-pref)

> simple preference control for electron

Automatically save your settings in a JSON file under electron.app.getPath('UserData') directory.  

This module can be used in both main and renderer process. And works well with webpack.

## Translations
[中文](README_CN.md)

## install
> npm install --save electron-pref

## usage
```JavaScript
const pref = require('electron-pref');
const setting = pref.from({
	foo: 'bar'
});

console.log(setting.get('foo'));
// -> 'bar'

setting.set('foo', 'baz');
console.log(setting.get('foo'));
// -> 'baz'
```

## license
[MIT](LICENSE)
