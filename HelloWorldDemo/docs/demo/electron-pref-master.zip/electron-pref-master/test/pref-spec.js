'use strict';
const os = require('os');
const assert = require('assert');
const Pref = require('../lib');

const {tmpdir} = os;
const is = assert.equal;
const VAL = '好';
let pref;

describe('handle pref', () => {
	beforeEach(() => {
		pref = new Pref({path: tmpdir()});
		pref.clear();
	});

	it('.get()', () => {
		is(pref.get('foo'), undefined);
		pref.set('foo', VAL);
		is(pref.get('foo'), VAL);
	});

	it('.set()', () => {
		pref.set('foo', VAL);
		pref.set('baz.foo', VAL);
		is(pref.get('foo'), VAL);
		is(pref.get('baz.foo'), VAL);
	});

	it('.set allow numerical keys', () => {
		pref.set(1, VAL);
		pref.set(NaN, VAL);
	});

	it('.has()', () => {
		pref.set('foo', VAL);
		pref.set('baz.foo', VAL);
		assert(pref.has('foo'));
		assert(pref.has('baz.foo'));
		assert(!pref.has(VAL));
	});

	it('.del()', () => {
		pref.set('foo', 'bar');
		pref.set('baz.foo', true);
		pref.set('baz.foo.bar', VAL);
		pref.delete('foo');
		is(pref.get('foo'), undefined);
		pref.delete('baz.foo');
		assert.notEqual(pref.get('baz.foo'), true);
		pref.delete('baz.boo');
		assert.notEqual(pref.get('baz.boo'), true);
	});

	it('.size', () => {
		pref.set('foo', 'bar');
		is(pref.size, 1);
	});

	it('.clear()', () => {
		pref.set('foo', 'bar');
		pref.set('baz.foo', true);
		pref.set('baz.foo.bar', VAL);
		pref.clear();
		is(pref.size, 0);
	});

	it('.store', () => {
		pref.set('foo', 'bar');
		const store = pref.store;
		assert(store instanceof Map);
	});

	it('use default options', () => {
		const myPref = new Pref({
			path: tmpdir(),
			default: {
				foo: 'bar'
			}
		});

		is(myPref.get('foo'), 'bar');
	});
});

describe('handle persist', () => {
	pref = new Pref({path: tmpdir()});

	it('set something', () => {
		pref.set('foo', VAL);
		pref.set('baz', VAL);
		is(pref.size, 2);
	});

	it('persist on disk', () => {
		pref = new Pref({
			path: tmpdir(),
			default: {
				foo: 'bar',
				baz: 'bar'
			}
		});

		is(pref.get('foo'), VAL);
		is(pref.get('baz'), VAL);
	});
});
